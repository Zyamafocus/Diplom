document.addEventListener('scroll', function() {
				// document.getElementById('showScroll').innerHTML = pageYOffset + 'px';
				if (window.pageYOffset > 250) {
								let figure = document.querySelectorAll(".ball1, .ball2");
								figure[0].style.display = "block";
								figure[1].style.display = "block";
				} else {
								let figure = document.querySelectorAll(".ball1, .ball2");
								figure[0].style.display = "none";
								figure[1].style.display = "none";
				}

				if (window.pageYOffset > 450) {
								let figure = document.querySelectorAll(".ball3, .ball4");
								figure[0].style.display = "block";
								figure[1].style.display = "block";
				} else {
								let figure = document.querySelectorAll(".ball3, .ball4");
								figure[0].style.display = "none";
								figure[1].style.display = "none";
				}
				if (window.pageYOffset > 650) {
								let figure = document.querySelectorAll(".ball5, .ball6");
								figure[0].style.display = "block";
								figure[1].style.display = "block";
				} else {
								let figure = document.querySelectorAll(".ball5, .ball6");
								figure[0].style.display = "none";
								figure[1].style.display = "none";
				}
});