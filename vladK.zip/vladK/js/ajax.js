let allusers = document.getElementById("all-Users");
let posts = document.querySelector("#posts");
let postbut = document.querySelector("#postsbtn");
let tabl = document.getElementById("result");
tabl.style.display = "none";
let butClk = document.getElementById("postsbtn");
butClk.style.display = "none";

//async logic
async function getAvtors() {
				const response = await fetch(
								`https://jsonplaceholder.typicode.com/users?_limit=10`
				);
				const data = await response.json();
				return data;
}

//event logic
document.addEventListener('DOMContentLoaded', initApp);

function initApp() {
				getAvtors().then(
								function(values) {
												values.forEach((avt) => printAvt(avt));
								}
				)
}

//basic logic
function printAvt({
				id,
				name
}) {
				var div = document.createElement('div');
				div.setAttribute("onclick", `infoShow(${id})`);
				div.innerHTML = `<span>${name}</span>`;
				allusers.append(div);

}

function printAvtInfo({
				id,
				name,
				username,
				address,
				email,
				phone,
				website
}) {
				tabl.style.display = "block";
				butClk.style.display = "block";
				var postes = document.getElementById('posts');
				postes.innerHTML = '';
				const streetUser = address.street;
				const cityUser = address.city;
				const suiteUser = address.suite;

				nameN.innerHTML = `<span>${name}</span>`;
				usernameU.innerHTML = `<span>${username}</span>`;
				addressA.innerHTML = `<span>${cityUser}, ${streetUser} ${suiteUser}</span>`;
				emailE.innerHTML = `<span>${email}</span>`;
				phoneP.innerHTML = `<span>${phone}</span>`;
				emailE.innerHTML = `<span>${email}</span>`;
				websiteW.innerHTML = `<span>${website}</span>`;

				postbut.setAttribute("onclick", `postsShow(${id})`);

}

function infoShow(id) {
				getAvtorsInfo(id).then(function(values) {
								printAvtInfo(values);
				});
			//	info.hidden = false;
}

async function getAvtorsInfo(id) {
				const response = await fetch(
								`https://jsonplaceholder.typicode.com/users/${id}/`
				);
				const data = await response.json();
				return data;
}

/*Третья часть "Посты" */

function postsShow(id) {
				getPosts(id).then(function(values) {
								values.forEach((post) => printPosts(post));
				});
}


async function getPosts(id) {
				const response = await fetch(
								`https://jsonplaceholder.typicode.com/posts?userId=${id}`
				);
				const data = await response.json();
				return data;
}

// ${userId}
function printPosts({
				userId,
				title,
				body
}) {
				var article = document.createElement('div');

				article.innerHTML = `<h4>${title}</h4><p>${body}</p>`;
				posts.append(article);



}